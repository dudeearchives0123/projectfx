package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Main extends Application {
    private static Connection connection;

    public static Connection connect() throws SQLException {
        if (connection == null) {
            String url = "jdbc:mysql://localhost/archives";
            String username = "root";
            String password = "Bec1234";

            try {
                connection = DriverManager.getConnection(url, username, password);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }

    public static void disconnect() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    public static void main(String args[]) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Create text fields for user input
        TextField usern = new TextField();
        usern.setPromptText("Username");

        PasswordField passw = new PasswordField();
        passw.setPromptText("Password");

        TextField barcode = new TextField();
        barcode.setPromptText("Barcode");

        // Create a button for registration
        Button registerBtn = new Button("Register");

        // Create a layout to hold the input elements and the registration button
        VBox root = new VBox(10);
        root.getChildren().addAll(usern, passw, barcode, registerBtn);
        root.setSpacing(10);

        // Create a scene and set it on the stage
        Scene scene = new Scene(root, 400, 200);
        primaryStage.setTitle("Registration");
        primaryStage.setScene(scene);

        // Show the stage
        primaryStage.show();

        // Set up the registration action
        registerBtn.setOnAction(e -> {
            String username = usern.getText();
            String password = passw.getText();
            String barcodeText = barcode.getText();

            // Check for empty input
            if (username.isEmpty() || password.isEmpty() || barcodeText.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Input Error");
                alert.setHeaderText(null);
                alert.setContentText("Please fill in all fields.");
                alert.showAndWait();
                return; // Exit registration if any field is empty
            }

            try {
                Connection connection = connect();
                String query = "INSERT INTO employets (Employee, Passwords, Barcode) VALUES (?, ?, ?)";
                PreparedStatement preparedStatement = connection.prepareStatement(query);
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, password);
                preparedStatement.setString(3, barcodeText);

                int result = preparedStatement.executeUpdate();
                preparedStatement.close();

                if (result > 0) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Registration Successful");
                    alert.setHeaderText(null);
                    alert.setContentText("Registration successful.");
                    alert.showAndWait();
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Registration Failed");
                    alert.setHeaderText(null);
                    alert.setContentText("Registration failed. Please try again.");
                    alert.showAndWait();
                }

                disconnect();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });
    }
}
